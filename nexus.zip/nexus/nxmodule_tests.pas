program nxmodule_tests;

{$mode objfpc}{$H+}

uses
  SysUtils,
  nxworkgraph,
  nxPasTokenTypes,
  nxPasDirectives,
  nxmodule;

type
  TNXTestSemanticResolver = class(TNXSemanticDirectiveResolver)
  private
    FStateMap: TNXStateMap;
    FBlockingWorkID: TNXWorkID;
    FRequiredState: TNXCompileState;
  public
    constructor Create(
      AStateMap: TNXStateMap;
      ABlockingWorkID: TNXWorkID;
      ARequiredState: TNXCompileState
    );

    function EvaluateConditional(
      const AExpression: string;
      out AValue: Boolean;
      out ABlocker: TNXBlockInfo
    ): Boolean; override;
  end;

  TNXTestBlockingModule = class(TNXModule)
  private
    FBlockingModule: TNXModule;
    FBlockingPhase: TNXModulePhase;
    FRequiredState: TNXCompileState;
    FHasBlocked: Boolean;
  protected
    function ExecutePhase(
      APhase: TNXModulePhase;
      AWorkspace: TNXModulePhaseWorkspace
    ): TNXTransitionResult; override;
  public
    procedure ConfigureBlock(
      APhase: TNXModulePhase;
      ABlockingModule: TNXModule;
      ARequiredState: TNXCompileState
    );
  end;

procedure Check(ACondition: Boolean; const AMessage: string);
begin
  if not ACondition then
    raise Exception.Create(AMessage);
end;

function NewUnit(
  AStateMap: TNXStateMap;
  const AName: string
): TNXModule;
begin
  Result := TNXModule.Create(
    AStateMap,
    'unit:' + LowerCase(AName),
    AName,
    AName + '.pas',
    'unit ' + AName + '; interface implementation end.',
    nmkUnit
  );
end;

procedure CompleteNext(AQueue: TNXAssignment; AExpected: TNXWorkItem);
var
  Work: TNXWorkItem;
  WorkResult: TNXWorkResult;
begin
  Check(AQueue.Next(Work), 'Expected queued work');
  Check(Work = AExpected, 'Scheduler selected unexpected work');
  WorkResult := Work.Process;
  AQueue.ReturnWork(Work, WorkResult);
  Check(WorkResult = wrCompleted, 'Expected work to complete');
end;

constructor TNXTestSemanticResolver.Create(
  AStateMap: TNXStateMap;
  ABlockingWorkID: TNXWorkID;
  ARequiredState: TNXCompileState
);
begin
  inherited Create;
  FStateMap := AStateMap;
  FBlockingWorkID := ABlockingWorkID;
  FRequiredState := ARequiredState;
end;

function TNXTestSemanticResolver.EvaluateConditional(
  const AExpression: string;
  out AValue: Boolean;
  out ABlocker: TNXBlockInfo
): Boolean;
begin
  ABlocker.Clear;

  if FStateMap.GetState(FBlockingWorkID) < Ord(FRequiredState) then
  begin
    AValue := False;
    ABlocker.WorkID := FBlockingWorkID;
    ABlocker.RequiredState := Ord(FRequiredState);
    ABlocker.Reason := AExpression;
    Exit(False);
  end;

  AValue := True;
  Result := True;
end;

procedure TNXTestBlockingModule.ConfigureBlock(
  APhase: TNXModulePhase;
  ABlockingModule: TNXModule;
  ARequiredState: TNXCompileState
);
begin
  FBlockingPhase := APhase;
  FBlockingModule := ABlockingModule;
  FRequiredState := ARequiredState;
end;

function TNXTestBlockingModule.ExecutePhase(
  APhase: TNXModulePhase;
  AWorkspace: TNXModulePhaseWorkspace
): TNXTransitionResult;
begin
  if (APhase = FBlockingPhase) and not FHasBlocked then
  begin
    AWorkspace.Advance;
    FHasBlocked := True;
    BlockCurrentPhaseOn(FBlockingModule, FRequiredState);
    Exit(trBlocked);
  end;

  Result := inherited ExecutePhase(APhase, AWorkspace);
end;

procedure TestConstructionAndPublication;
var
  StateMap: TNXStateMap;
  Module: TNXModule;
  Snapshot: TNXModuleSnapshot;
begin
  StateMap := TNXStateMap.Create;
  Module := NewUnit(StateMap, 'Alpha');
  try
    Check(not Module.Started, 'New module must not be started');
    Check(Module.ClonePublished = nil, 'New module must not publish data');
    Check(Module.Process = wrCompleted, 'Module did not complete');

    Snapshot := Module.ClonePublished;
    try
      Check(Snapshot <> nil, 'Completed module has no snapshot');
      Check(Snapshot.Identity = 'unit:alpha', 'Snapshot identity changed');
      Check(Snapshot.ModuleName = 'Alpha', 'Snapshot module name changed');
      Check(Snapshot.State = csProcessed, 'Snapshot has wrong final state');
      Check(Snapshot.Revision = 10, 'Unexpected published revision count');
      Check(Snapshot.TokenStream <> nil, 'Token stream was not published');
      Check(Snapshot.TokenStream.TokenCount > 1, 'Token stream is empty');
      Check(
        Snapshot.Phase[nmpImplementation].Completed,
        'Implementation phase was not published as complete'
      );
    finally
      Snapshot.Free;
    end;
  finally
    Module.Free;
    StateMap.Free;
  end;
end;

procedure TestStaticDependencyScheduling;
var
  StateMap: TNXStateMap;
  Queue: TNXAssignment;
  Consumer: TNXModule;
  Provider: TNXModule;
  Work: TNXWorkItem;
  WorkResult: TNXWorkResult;
begin
  StateMap := TNXStateMap.Create;
  Queue := TNXAssignment.Create(StateMap);
  Consumer := NewUnit(StateMap, 'Consumer');
  Provider := NewUnit(StateMap, 'Provider');
  try
    Consumer.RequireInterface(Provider);
    Queue.Add(Consumer);
    Queue.Add(Provider);

    Check(Queue.Next(Work), 'Expected consumer work');
    Check(Work = Consumer, 'Queue order changed before blocking');
    WorkResult := Work.Process;
    Check(WorkResult = wrBlocked, 'Consumer did not block');
    Queue.ReturnWork(Work, WorkResult);

    CompleteNext(Queue, Provider);
    CompleteNext(Queue, Consumer);

    Check(Queue.BlockedCount = 0, 'Blocked queue was not drained');
    Check(Consumer.Completed, 'Consumer did not complete');
  finally
    Provider.Free;
    Consumer.Free;
    Queue.Free;
    StateMap.Free;
  end;
end;

procedure TestTokenizerResumeWithoutPartialPublication;
var
  StateMap: TNXStateMap;
  Queue: TNXAssignment;
  Provider: TNXModule;
  Consumer: TNXModule;
  Resolver: TNXTestSemanticResolver;
  Work: TNXWorkItem;
  WorkResult: TNXWorkResult;
  Snapshot: TNXModuleSnapshot;
begin
  StateMap := TNXStateMap.Create;
  Queue := TNXAssignment.Create(StateMap);
  Provider := NewUnit(StateMap, 'SemanticProvider');
  Resolver := TNXTestSemanticResolver.Create(
    StateMap,
    Provider.WorkID,
    csProcessed
  );
  Consumer := TNXModule.Create(
    StateMap,
    'unit:semanticconsumer',
    'SemanticConsumer',
    'SemanticConsumer.pas',
    'unit SemanticConsumer; interface ' +
    '{$if SizeOf(SemanticProvider.TValue) = 4}' +
    'const Answer = 42; {$endif} implementation end.',
    nmkUnit,
    nil,
    Resolver
  );
  try
    Queue.Add(Consumer);
    Queue.Add(Provider);

    Check(Queue.Next(Work), 'Expected semantic consumer work');
    Check(Work = Consumer, 'Unexpected initial semantic work');
    WorkResult := Work.Process;
    Check(WorkResult = wrBlocked, 'Tokenizer did not block');
    Queue.ReturnWork(Work, WorkResult);

    Check(
      Consumer.State = Ord(csTokenizing),
      'Blocked tokenizer advanced its semantic state'
    );
    Check(
      Consumer.WorkingPhase(nmpContinueTokenizing).Cursor = 1,
      'Tokenizer working progress was not retained'
    );

    Snapshot := Consumer.ClonePublished;
    try
      Check(Snapshot <> nil, 'Tokenizing state was not published');
      Check(
        Snapshot.Phase[nmpContinueTokenizing].Cursor = 0,
        'Partial tokenizer progress leaked into published data'
      );
      Check(
        Snapshot.TokenStream = nil,
        'Partial token stream was published'
      );
    finally
      Snapshot.Free;
    end;

    CompleteNext(Queue, Provider);
    CompleteNext(Queue, Consumer);

    Snapshot := Consumer.ClonePublished;
    try
      Check(Snapshot.TokenStream <> nil, 'Completed tokens were not published');
      Check(
        Snapshot.Phase[nmpContinueTokenizing].Cursor = 2,
        'Tokenizer did not resume its retained work'
      );
    finally
      Snapshot.Free;
    end;
  finally
    Consumer.Free;
    Resolver.Free;
    Provider.Free;
    Queue.Free;
    StateMap.Free;
  end;
end;

procedure TestNonTokenizerPhaseResume;
var
  StateMap: TNXStateMap;
  Queue: TNXAssignment;
  Provider: TNXModule;
  Consumer: TNXTestBlockingModule;
  Work: TNXWorkItem;
  WorkResult: TNXWorkResult;
  BlockedSnapshot: TNXModuleSnapshot;
  CompletedSnapshot: TNXModuleSnapshot;
begin
  StateMap := TNXStateMap.Create;
  Queue := TNXAssignment.Create(StateMap);
  Provider := NewUnit(StateMap, 'PhaseProvider');
  BlockedSnapshot := nil;
  CompletedSnapshot := nil;
  Consumer := TNXTestBlockingModule.Create(
    StateMap,
    'unit:phaseconsumer',
    'PhaseConsumer',
    'PhaseConsumer.pas',
    'unit PhaseConsumer; interface implementation end.',
    nmkUnit
  );
  try
    Consumer.ConfigureBlock(
      nmpImplementation,
      Provider,
      csProcessed
    );
    Queue.Add(Consumer);
    Queue.Add(Provider);

    Check(Queue.Next(Work), 'Expected phase consumer work');
    Check(Work = Consumer, 'Unexpected initial phase work');
    WorkResult := Work.Process;
    Check(WorkResult = wrBlocked, 'Implementation phase did not block');
    Queue.ReturnWork(Work, WorkResult);

    Check(
      Consumer.WorkingPhase(nmpImplementation).Cursor = 1,
      'Private implementation progress was not retained'
    );

    BlockedSnapshot := Consumer.ClonePublished;
    Check(
      BlockedSnapshot.Phase[nmpImplementation].Cursor = 0,
      'Partial implementation progress was published'
    );
    Check(
      BlockedSnapshot.State = csCompilingWaitIntf,
      'Blocked implementation advanced module state'
    );

    CompleteNext(Queue, Provider);
    CompleteNext(Queue, Consumer);

    CompletedSnapshot := Consumer.ClonePublished;
    Check(
      CompletedSnapshot.Phase[nmpImplementation].Cursor = 2,
      'Implementation work did not resume from retained progress'
    );
    Check(
      CompletedSnapshot.Phase[nmpImplementation].Completed,
      'Resumed implementation phase did not complete'
    );
    Check(
      BlockedSnapshot.Phase[nmpImplementation].Cursor = 0,
      'A previously published snapshot changed after a later commit'
    );
    Check(
      BlockedSnapshot.State = csCompilingWaitIntf,
      'A previously published state changed after a later commit'
    );
  finally
    CompletedSnapshot.Free;
    BlockedSnapshot.Free;
    Consumer.Free;
    Provider.Free;
    Queue.Free;
    StateMap.Free;
  end;
end;

begin
  TestConstructionAndPublication;
  WriteLn('PASS construction and publication');

  TestStaticDependencyScheduling;
  WriteLn('PASS static dependency scheduling');

  TestTokenizerResumeWithoutPartialPublication;
  WriteLn('PASS tokenizer resume and publication isolation');

  TestNonTokenizerPhaseResume;
  WriteLn('PASS non-tokenizer phase resume and publication isolation');

  WriteLn('All nxmodule tests passed.');
end.
