# Nexus Pascal Tokenizer Prototype

This is a clean-room tokenizer prototype based on the lexical behavior observed in the supplied NexusFPC/FPC snapshot and on the architecture discussed for NexusFPC.

## Core rules implemented

- Tokenization produces a durable, immutable token buffer only when complete.
- Compiler directives are consumed during tokenization and never become parser tokens.
- Includes are expanded through a source stack into one logical token stream.
- Conditional compilation is processed by the directive layer.
- `{$IF ...}` expressions that cannot be resolved lexically can delegate to `TNXSemanticDirectiveResolver`.
- A semantic resolver can return a `TNXBlockInfo`; the tokenizer then returns `tsBlocked` while retaining all work already performed.
- Resuming calls `Continue` again. The pending directive is retried before additional source is consumed.
- Operators and keywords do not retain redundant source strings.
- Identifiers are interned in a string pool.
- Literal values are stored in a separate pool.
- `<` and `>` are always lexical operator facts; parser context does not alter their token identity.
- Known FPC words retain a keyword-candidate ID even when emitted as identifiers.
- A keyword policy decides whether a known word is active as a keyword.

## Units

- `nxPasTokenTypes.pas` — token records, token kinds, pools, blocker information.
- `nxPasKeywords.pas` — 218 known words extracted from the supplied FPC token table, plus keyword lookup/policy.
- `nxPasSources.pas` — source and include stack abstraction.
- `nxPasDirectives.pas` — define/undef, include, conditional state, semantic-directive resolver boundary.
- `nxPasFileSources.pas` — simple filesystem include provider.
- `nxPasTokenizer.pas` — tokenizer proper.
- `tokenizer_demo.pas` — minimal use example.

## Deliberately not copied from FPC

The prototype does not reproduce FPC's scanner architecture. In particular it does not carry forward:

- parser-controlled `block_type` token reinterpretation;
- token record/replay machinery;
- the scanner's `current_scanner` global model;
- C-macro substitution;
- every historical compiler directive;
- every language-mode switch;
- parser AST/symbol ownership.

Those can be added only where compatibility requires them.

## Implemented lexical forms

The prototype currently recognizes:

- identifiers, including `&escaped` identifiers;
- FPC keyword candidates;
- decimal integers;
- `$` hexadecimal integers;
- `%` binary integers;
- `&` octal integers;
- decimal real literals with exponent;
- Pascal quoted strings with doubled apostrophes;
- `#nn` and `#$nn` character-code literals;
- standard Pascal punctuation/operators;
- `:=`, `..`, `...`, `<>`, `>=`, `<=`, `><`, `**`;
- several compound assignment operators;
- `{...}`, `(*...*)`, and `//...` comments;
- `{$...}` and `(*$...*)` directives;
- nested ordinary comments in the prototype;
- include expansion.

## Directive behavior

Built in:

- `$DEFINE`
- `$UNDEF`
- `$IFDEF`
- `$IFNDEF`
- `$IF`
- `$ELSE`
- `$ENDIF` / `$IFEND`
- `$I` / `$INCLUDE`

`$IF` handles simple `DEFINED(...)`, `NOT`, `AND`, `OR`, and boolean/defined-symbol tests locally. More complex expressions — including semantic FPC/Delphi-style checks such as `DECLARED`, `SIZEOF`, or `HIGH` — are delegated through `TNXSemanticDirectiveResolver`.

Unknown active directives are consumed and may be observed through `OnUnknownDirective`. This is intentional: directives never leak into the parser token stream.

## Important prototype limits

This is an architectural prototype, not yet a drop-in replacement for `scanner.pas`.

Before compiler integration, the next compatibility pass should cover:

- exact NexusFPC language-mode keyword policy;
- all retained compiler directives and mode switches;
- wide/unicode string/character lexical forms;
- source encoding/codepage behavior;
- exact numeric overflow/validation rules;
- FPC-specific string modes and multiline strings if retained;
- exact comment-nesting switches;
- any retained macro extension;
- diagnostics parity;
- a differential token-dump test against the existing scanner.

The preferred validation method is to normalize the existing scanner output and this tokenizer output over the NexusFPC corpus and investigate every mismatch.

## Block/resume model

A semantic directive does not discard tokenizer work:

```text
source
  -> tokens...
  -> semantic directive cannot resolve
  -> retain token buffer + source/include/directive state
  -> return tsBlocked

dependency progresses

Continue
  -> retry pending directive
  -> continue at exact source position
  -> eventually complete
  -> publish full immutable token buffer
```

No partial token buffer is presented as `Tokenized`.

## Memory model

`TNXToken` is intentionally fixed-size and contains IDs/positions rather than copied operator or keyword strings. Identifier and literal payloads live in separate pools. This is meant to keep the primary token walk contiguous and cache-friendly.

